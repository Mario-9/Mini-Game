print ("Welcome to The Justice League:")
print (" ")
print ("Rules you should know:")
print ("-Aquaman drowns Batman")
print ("-Superman pummels Aquaman")
print ("-Batman kills Superman with Kryptonite")
print (" ")
print ("Now let's battle!")
print (" ")
import random
choices = ("Aquaman", "Superman", "Batman")
userChoice = input("Choose your hero: ")
CPUchoice = random.choice(choices)
print ("Computer chooses: " + CPUchoice)
print (" ")
if (userChoice == CPUchoice):
  print ("It's a tie... try again.")
elif (userChoice == "Aquaman" and CPUchoice == "Batman"):
  print ("Congratulations, you have defeated Batman.")
elif (userChoice == "Aquaman" and CPUchoice == "Superman"):
  print ("You have been defeated... try again.")
elif (userChoice == "Superman" and CPUchoice == "Aquaman"):
  print ("Congratulations, you have defeated Aquaman.")
elif (userChoice == "Superman" and CPUchoice == "Batman"):
  print ("You have been defeated... try again.")
elif (userChoice == "Batman" and CPUchoice == "Superman"):
  print ("Congratulations, you have defeated Superman.")
elif (userChoice == "Batman" and CPUchoice == "Aquaman"):
  print ("You have been defeated... try again")